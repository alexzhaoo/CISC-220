#!/usr/bin/env bash

n=$RANDOM
x=$((n % 2))
echo "$x"
